import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import 'edit_profile_page.dart';
import 'profile_provider.dart';
import 'faq_page.dart';
import 'auth_provider.dart'; // Ensure this is imported

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final profileProvider = Provider.of<ProfileProvider>(context);

    // Ensure a unique ID is set
    _ensureUniqueId(profileProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
        backgroundColor: Colors.blueAccent,
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              Provider.of<AuthProvider>(context, listen: false).logout();
              Navigator.of(context).pushReplacementNamed('/signin');
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Stack(
              alignment: Alignment.center,
              children: <Widget>[
                Container(
                  width: double.infinity,
                  height: 250,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    image: DecorationImage(
                      fit: BoxFit.cover,
                      image: NetworkImage(
                        'https://images.unsplash.com/photo-1434394354979-a235cd36269d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTJ8fG1vdW50YWluc3xlbnwwfHwwfHw%3D&auto=format&fit=crop&w=900&q=60',
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 160,
                  child: CircleAvatar(
                    radius: 70,
                    backgroundImage: NetworkImage(profileProvider.photoUrl),
                    backgroundColor: Colors.white,
                    child: Align(
                      alignment: Alignment.bottomRight,
                      child: CircleAvatar(
                        backgroundColor: Colors.blueAccent,
                        radius: 20,
                        child: Icon(
                          Icons.camera_alt,
                          size: 20,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                children: <Widget>[
                  SizedBox(height: 80),
                  Center(
                    child: Text(
                      profileProvider.name,
                      style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Center(
                    child: Text(
                      'ID: ${profileProvider.id}',  // Display the unique ID
                      style: TextStyle(fontSize: 16, color: Colors.grey),
                    ),
                  ),
                  Center(
                    child: Text(
                      profileProvider.email,
                      style: TextStyle(fontSize: 18, color: Colors.grey),
                    ),
                  ),
                  SizedBox(height: 30),
                  buildButton(context, Icons.edit, 'Edit Profile', Colors.blueAccent, EditProfilePage()),
                  SizedBox(height: 10),
                  buildButton(context, Icons.help_outline, 'FAQ', Colors.blueAccent, FaqPage()),
                  SizedBox(height: 10),
                  buildButton(context, Icons.logout, 'Sign Out', Colors.redAccent, null),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _ensureUniqueId(ProfileProvider profileProvider) {
    if (profileProvider.id == null || profileProvider.id.isEmpty) {
      var uuid = Uuid();
      profileProvider.setId(uuid.v4());  // Method to set ID in the profile provider
    }
  }

  Widget buildButton(BuildContext context, IconData icon, String label, Color color, Widget? page) {
    return SizedBox(
      width: double.infinity,  // Ensures the button stretches to fill the width
      child: ElevatedButton.icon(
        onPressed: () {
          if (page != null) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => page),
            );
          } else {
            Provider.of<AuthProvider>(context, listen: false).logout();
            Navigator.of(context).pushReplacementNamed('/signin');
          }
        },
        icon: Icon(icon, size: 20),
        label: Text(label),
        style: ElevatedButton.styleFrom(
          primary: color,
          onPrimary: Colors.white,
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          textStyle: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),  // Rounded corners
          ),
          elevation: 5,  // Adds a shadow
        ),
      ),
    );
  }
}
