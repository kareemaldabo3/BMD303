import 'package:flutter/material.dart';

class AuthProvider with ChangeNotifier {
  bool _isAuthenticated = false;
  String _currentUser = '';
  final Map<String, String> _users = {
    'test@test.com': 'password',
  };

  bool get isAuthenticated => _isAuthenticated;
  String get currentUser => _currentUser;

  void signIn(String email, String password) {
    if (_users.containsKey(email) && _users[email] == password) {
      _isAuthenticated = true;
      _currentUser = email;
      notifyListeners();
    } else {
      _isAuthenticated = false;
      notifyListeners();
    }
  }

  void signUp(String email, String password) {
    if (!_users.containsKey(email)) {
      _users[email] = password;
      _isAuthenticated = true;
      _currentUser = email;
      notifyListeners();
    } else {
      _isAuthenticated = false;
      notifyListeners();
    }
  }

  void signOut() {
    _isAuthenticated = false;
    _currentUser = '';
    notifyListeners();
  }

void login(String username, String password) {
    // Implement login logic here
    _isAuthenticated = true;
    notifyListeners();
  }

  void logout() {
    _isAuthenticated = false;
    notifyListeners();
  }
}
