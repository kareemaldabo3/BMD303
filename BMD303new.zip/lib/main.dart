import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'auth_provider.dart';
import 'profile_provider.dart';
import 'sign_in_page.dart';
import 'main_screen.dart';
import 'home_page_widget.dart';

void main() {
  runApp(ReservationApp());
}

class ReservationApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => AuthProvider()),
        ChangeNotifierProvider(create: (context) => ProfileProvider()),
      ],
      child: MaterialApp(
        title: 'Dental Clinic Reservation',
        theme: ThemeData(
          primarySwatch: Colors.blue,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        home: Consumer<AuthProvider>(
          builder: (context, authProvider, child) {
            if (authProvider.isAuthenticated) {
              return MainScreen();
            } else {
              return SignInPage();
            }
          },
        ),
        routes: {
          '/home': (context) => HomePageWidget(),
          // Add more routes as needed
        },
      ),
    );
  }
}
