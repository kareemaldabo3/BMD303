import 'package:flutter/material.dart';

class ProfileData with ChangeNotifier {
  String _name = 'John Doe';
  String _email = 'john.doe@example.com';
  String _phone = '(123) 456-7890';
  String _address = '123 Main St, Springfield';
  String _bio = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.';
  String _profilePictureUrl = 'https://source.unsplash.com/random/200x200?person';

  String get name => _name;
  String get email => _email;
  String get phone => _phone;
  String get address => _address;
  String get bio => _bio;
  String get profilePictureUrl => _profilePictureUrl;

  void updateProfile(String name, String email, String phone, String address, String bio, String profilePictureUrl) {
    _name = name;
    _email = email;
    _phone = phone;
    _address = address;
    _bio = bio;
    _profilePictureUrl = profilePictureUrl;
    notifyListeners();
  }
}
