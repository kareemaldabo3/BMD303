import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'booking_calendar.dart';
import 'booking_controller.dart';
import 'booking_service.dart';
import 'enums.dart';
import 'booking_util.dart';
import 'common_button.dart';
import 'common_card.dart';

class BookingCalendarMain extends StatefulWidget {
  @override
  _BookingCalendarMainState createState() => _BookingCalendarMainState();
}

class _BookingCalendarMainState extends State<BookingCalendarMain> {
  late BookingService bookingService;
  late BookingController bookingController;
  DateTime _selectedDay = DateTime.now();
  DateTime _focusedDay = DateTime.now();

  @override
  void initState() {
    super.initState();
    bookingService = BookingService();
    bookingController = BookingController();
  }

  List<DateTime> _getAvailableSlotsForDay(DateTime day) {
    // Get the available slots for the selected day
    return bookingService.getAvailableSlots(day);
  }

  void _showBookingConfirmationDialog(DateTime slot) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Booking Confirmation'),
        content: Text('Your booking for ${BookingUtil.formatDate(slot)} has been confirmed.'),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    List<DateTime> availableSlots = _getAvailableSlotsForDay(_selectedDay);

    return Scaffold(
      appBar: AppBar(
        title: Text('Booking Calendar'),
      ),
      body: Column(
        children: [
          TableCalendar(
            firstDay: DateTime.utc(2020, 1, 1),
            lastDay: DateTime.utc(2030, 12, 31),
            focusedDay: _focusedDay,
            selectedDayPredicate: (day) {
              return isSameDay(_selectedDay, day);
            },
            onDaySelected: (selectedDay, focusedDay) {
              setState(() {
                _selectedDay = selectedDay;
                _focusedDay = focusedDay;
                availableSlots = _getAvailableSlotsForDay(selectedDay);
              });
            },
          ),
          SizedBox(height: 16.0),
          Text(
            'Available Slots for ${BookingUtil.formatDate(_selectedDay)}',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: availableSlots.length,
              itemBuilder: (context, index) {
                DateTime slot = availableSlots[index];
                return ListTile(
                  title: Text(BookingUtil.formatDate(slot)),
                  trailing: Icon(Icons.arrow_forward),
                  onTap: () {
                    bool success = bookingService.bookSlot(slot);
                    if (success) {
                      setState(() {
                        availableSlots = _getAvailableSlotsForDay(_selectedDay);
                      });
                      _showBookingConfirmationDialog(slot);
                    } else {
                      showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: Text('Booking Failed'),
                          content: Text('The slot for ${BookingUtil.formatDate(slot)} is no longer available.'),
                          actions: <Widget>[
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              child: Text('OK'),
                            ),
                          ],
                        ),
                      );
                    }
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
