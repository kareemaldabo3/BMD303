import 'package:flutter/material.dart';

import 'booking_dialog.dart';

class BookingSlot extends StatelessWidget {
  final DateTime startTime;
  final DateTime endTime;

  BookingSlot({required this.startTime, required this.endTime});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(
        '${startTime.hour}:${startTime.minute} - ${endTime.hour}:${endTime.minute}',
      ),
      trailing: Icon(Icons.chevron_right),
      onTap: () {
        // Navigate to booking confirmation dialog
        showDialog(
          context: context,
          builder: (context) => BookingDialog(),
        );
      },
    );
  }
}
