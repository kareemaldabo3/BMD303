import 'package:flutter/material.dart';

class BookingService {
  List<DateTime> availableSlots = [];
  Map<DateTime, List<DateTime>> bookedSlots = {};

  BookingService() {
    // Initialize with some dummy available slots
    initializeSlots();
  }

  void initializeSlots() {
    DateTime now = DateTime.now();
    availableSlots = [
      now.add(Duration(hours: 1)),
      now.add(Duration(hours: 2)),
      now.add(Duration(hours: 3)),
      now.add(Duration(hours: 4)),
    ];
  }

  List<DateTime> getAvailableSlots(DateTime day) {
    if (bookedSlots.containsKey(day)) {
      return availableSlots.where((slot) => !bookedSlots[day]!.contains(slot)).toList();
    }
    return availableSlots;
  }

  bool bookSlot(DateTime slot) {
    DateTime day = DateTime(slot.year, slot.month, slot.day);
    if (!bookedSlots.containsKey(day)) {
      bookedSlots[day] = [];
    }
    if (availableSlots.contains(slot) && !bookedSlots[day]!.contains(slot)) {
      bookedSlots[day]!.add(slot);
      return true;
    }
    return false;
  }
}
