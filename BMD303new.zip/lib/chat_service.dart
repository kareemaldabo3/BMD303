import 'dart:convert';
import 'package:http/http.dart' as http;
import 'message_model.dart';

class ChatService {
  Future<Message> sendMessage(String query) async {
    const String apiKey = 'AIzaSyA6VGHynSzcyAeGUYXipP24Wzbihb929Sc'; // Replace with your actual API key
    const String apiUrl = 'https://api.gemini.com/v1/converse'; // Replace with the correct endpoint

    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {
        'Authorization': 'Bearer $apiKey',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'input': query,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final message = data['response']; // Adjust according to the actual response structure
      return Message(text: message, sender: 'bot');
    } else {
      throw Exception('Failed to load response');
    }
  }

  fetchMessages() {}
}
