import 'dart:async';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:provider/provider.dart';
import 'sign_up_page.dart';
import 'main_screen.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: SignInPage(),
    );
  }
}

class SignInPage extends StatefulWidget {
  @override
  _SignInPageState createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  int activeIndex = 0;

  @override
  void initState() {
    Timer.periodic(Duration(seconds: 5), (timer) {
      setState(() {
        activeIndex++;
        if (activeIndex == 4) activeIndex = 0;
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Welcome')),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Column(
            children: [
              SizedBox(height: 50),
              Container(
                height: 350,
                child: Stack(
                  children: [
                    buildPositioned(activeIndex == 0, 'assets/images/prophoto1.jpeg'),
                    buildPositioned(activeIndex == 1, 'assets/images/prophoto2.jpg'),
                    buildPositioned(activeIndex == 2, 'assets/images/prophoto3.jpg'),
                    buildPositioned(activeIndex == 3, 'assets/images/prophoto4.jpg'),
                  ],
                ),
              ),
              SizedBox(height: 40),
              SignInForm(),
              SizedBox(height: 30),
              MaterialButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SignUpPage())),
                height: 45,
                color: Colors.black,
                child: Text("Register", style: TextStyle(color: Colors.white, fontSize: 16.0)),
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Positioned buildPositioned(bool visible, String imagePath) {
    return Positioned(
      top: 0, left: 0, right: 0, bottom: 0,
      child: AnimatedOpacity(
        opacity: visible ? 1 : 0,
        duration: Duration(seconds: 1),
        curve: Curves.linear,
        child: Image.asset(imagePath, height: 400),
      ),
    );
  }
}

class SignInForm extends StatefulWidget {
  @override
  _SignInFormState createState() => _SignInFormState();
}

class _SignInFormState extends State<SignInForm> {
  final _formKey = GlobalKey<FormState>();
  String _email = '';
  String _password = '';
  bool _showPassword = false;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: <Widget>[
          TextFormField(
            decoration: InputDecoration(labelText: 'Email', border: OutlineInputBorder()),
            validator: (value) {
              if (value == null || value.isEmpty) return 'Please enter your email';
              return null;
            },
            onSaved: (value) => _email = value!,
          ),
          SizedBox(height: 20),
          TextFormField(
            decoration: InputDecoration(
              labelText: 'Password',
              border: OutlineInputBorder(),
              suffixIcon: IconButton(
                icon: Icon(_showPassword ? Icons.visibility : Icons.visibility_off),
                onPressed: () => setState(() => _showPassword = !_showPassword),
              ),
            ),
            obscureText: !_showPassword,
            validator: (value) {
              if (value == null || value.isEmpty) return 'Please enter your password';
              return null;
            },
            onSaved: (value) => _password = value!,
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                _formKey.currentState!.save();
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MainScreen()));
              }
            },
            child: Text('Sign In'),
          ),
        ],
      ),
    );
  }
}
